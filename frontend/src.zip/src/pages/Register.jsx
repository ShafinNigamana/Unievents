import { useState } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";

export default function Register() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    enrollmentNumber: "",
    department: "",
    semester: "",
    phone: "",
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleRegister = async (e) => {
    e.preventDefault();

    try {
      const res = await axios.post("http://localhost:5000/api/auth/register", {
        ...form,
        semester: form.semester ? Number(form.semester) : null,
      });

      localStorage.setItem("user", JSON.stringify(res.data));
      alert("Registered Successfully ✅");
      navigate("/dashboard");
    } catch (err) {
      alert(err.response?.data?.message || "Register failed ❌");
    }
  };

  return (
    <div className="min-h-screen bg-gray-950 text-white flex items-center justify-center p-6">
      <div className="w-full max-w-lg bg-gray-900 border border-gray-800 rounded-2xl p-6">
        <h1 className="text-2xl font-bold">Register 📝</h1>
        <p className="text-gray-400 mt-1">Create your Unievents account</p>

        <form onSubmit={handleRegister} className="mt-5 grid gap-3">
          <input
            className="bg-gray-950 border border-gray-800 rounded-xl p-3"
            placeholder="Full Name *"
            name="name"
            value={form.name}
            onChange={handleChange}
          />

          <input
            className="bg-gray-950 border border-gray-800 rounded-xl p-3"
            placeholder="Email *"
            name="email"
            value={form.email}
            onChange={handleChange}
          />

          <input
            type="password"
            className="bg-gray-950 border border-gray-800 rounded-xl p-3"
            placeholder="Password *"
            name="password"
            value={form.password}
            onChange={handleChange}
          />

          <input
            className="bg-gray-950 border border-gray-800 rounded-xl p-3"
            placeholder="Enrollment Number * (ex: D25DIT094)"
            name="enrollmentNumber"
            value={form.enrollmentNumber}
            onChange={handleChange}
          />

          <input
            className="bg-gray-950 border border-gray-800 rounded-xl p-3"
            placeholder="Department (optional)"
            name="department"
            value={form.department}
            onChange={handleChange}
          />

          <input
            className="bg-gray-950 border border-gray-800 rounded-xl p-3"
            placeholder="Semester (optional)"
            name="semester"
            value={form.semester}
            onChange={handleChange}
          />

          <input
            className="bg-gray-950 border border-gray-800 rounded-xl p-3"
            placeholder="Phone (optional)"
            name="phone"
            value={form.phone}
            onChange={handleChange}
          />

          <button className="bg-blue-600 hover:bg-blue-500 transition rounded-xl p-3 font-semibold">
            Register
          </button>
        </form>

        <p className="text-gray-400 mt-4 text-sm">
          Already have an account?{" "}
          <Link className="text-blue-400 underline" to="/login">
            Login
          </Link>
        </p>
      </div>
    </div>
  );
}
