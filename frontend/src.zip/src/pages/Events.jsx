import { useEffect, useState } from "react";
import axios from "axios";
import Navbar from "../components/Navbar";

export default function Events() {
  const API = "http://localhost:5000/api/events";

  // 🔐 Auth data (UPDATED to match new Login.jsx)
  const token = localStorage.getItem("token");
  const user = JSON.parse(localStorage.getItem("user"));
  const role = user?.role;
  const isEditor = role === "admin" || role === "organizer";

  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");

  // Form State
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [date, setDate] = useState("");
  const [venue, setVenue] = useState("");
  const [category, setCategory] = useState("Other");
  const [status, setStatus] = useState("draft");
  const [editId, setEditId] = useState(null);

  // Axios auth header
  const authHeader = {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  };

  // FETCH EVENTS
  const fetchEvents = async () => {
    try {
      const res = await axios.get(API, authHeader);
      setEvents(res.data);
    } catch (err) {
      console.log(err);
      alert("Failed to fetch events ❌");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEvents();
  }, []);

  // CLEAR FORM
  const clearForm = () => {
    setTitle("");
    setDescription("");
    setDate("");
    setVenue("");
    setCategory("Other");
    setStatus("draft");
    setEditId(null);
  };

  // CREATE / UPDATE (admin / organizer only)
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!isEditor) {
      alert("You do not have permission ❌");
      return;
    }

    if (!title.trim() || !date) {
      alert("Title and Date are required ❗");
      return;
    }

    try {
      if (editId) {
        await axios.put(
          `${API}/${editId}`,
          { title, description, date, venue, category, status },
          authHeader
        );
      } else {
        await axios.post(
          API,
          { title, description, date, venue, category, status },
          authHeader
        );
      }

      clearForm();
      fetchEvents();
    } catch (err) {
      console.log(err);
      alert("Failed to save event ❌");
    }
  };

  // EDIT
  const handleEdit = (event) => {
    if (!isEditor) return;

    setEditId(event._id);
    setTitle(event.title);
    setDescription(event.description || "");
    setDate(event.date ? event.date.slice(0, 10) : "");
    setVenue(event.venue || "");
    setCategory(event.category || "Other");
    setStatus(event.status || "draft");
  };

  // DELETE
  const handleDelete = async (id) => {
    if (!isEditor) {
      alert("You do not have permission ❌");
      return;
    }

    const ok = confirm("Delete this event?");
    if (!ok) return;

    try {
      await axios.delete(`${API}/${id}`, authHeader);
      fetchEvents();
    } catch (err) {
      console.log(err);
      alert("Failed to delete ❌");
    }
  };

  const filteredEvents =
    filter === "all"
      ? events
      : events.filter((e) => e.status === filter);

  const TabButton = ({ label, value }) => (
    <button
      onClick={() => setFilter(value)}
      className={`px-4 py-2 rounded-xl font-semibold border transition ${
        filter === value
          ? "bg-blue-600 border-blue-500"
          : "bg-gray-900 border-gray-800 hover:bg-gray-800"
      }`}
    >
      {label}
    </button>
  );

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      <Navbar />

      <div className="max-w-6xl mx-auto p-6">
        <h1 className="text-3xl font-bold">Events 📌</h1>
        <p className="text-gray-400 mt-1">
          View, manage and archive university events.
        </p>

        {/* Filters */}
        <div className="flex flex-wrap gap-2 mt-5">
          <TabButton label="All" value="all" />
          <TabButton label="Published" value="published" />
          <TabButton label="Archived" value="archived" />
          <TabButton label="Draft" value="draft" />
        </div>

        {/* FORM (admin / organizer only) */}
        {isEditor && (
          <div className="mt-6 bg-gray-900 border border-gray-800 rounded-2xl p-5">
            <h2 className="text-xl font-semibold mb-4">
              {editId ? "Edit Event ✏️" : "Create New Event ➕"}
            </h2>

            <form onSubmit={handleSubmit} className="grid gap-3">
              <input
                className="bg-gray-950 border border-gray-800 rounded-xl p-3"
                placeholder="Event Title *"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />

              <textarea
                className="bg-gray-950 border border-gray-800 rounded-xl p-3"
                placeholder="Event Description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
              />

              <input
                type="date"
                className="bg-gray-950 border border-gray-800 rounded-xl p-3"
                value={date}
                onChange={(e) => setDate(e.target.value)}
              />

              <input
                className="bg-gray-950 border border-gray-800 rounded-xl p-3"
                placeholder="Venue"
                value={venue}
                onChange={(e) => setVenue(e.target.value)}
              />

              <div className="grid md:grid-cols-2 gap-3">
                <select
                  className="bg-gray-950 border border-gray-800 rounded-xl p-3"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                >
                  <option>Cultural</option>
                  <option>Technical</option>
                  <option>Sports</option>
                  <option>Workshop</option>
                  <option>Other</option>
                </select>

                <select
                  className="bg-gray-950 border border-gray-800 rounded-xl p-3"
                  value={status}
                  onChange={(e) => setStatus(e.target.value)}
                >
                  <option value="draft">Draft</option>
                  <option value="published">Published</option>
                  <option value="archived">Archived</option>
                </select>
              </div>

              <div className="flex gap-3">
                <button className="flex-1 bg-blue-600 rounded-xl p-3 font-semibold">
                  {editId ? "💾 Update Event" : "➕ Add Event"}
                </button>

                {editId && (
                  <button
                    type="button"
                    onClick={clearForm}
                    className="flex-1 bg-gray-800 rounded-xl p-3 font-semibold"
                  >
                    ❌ Cancel
                  </button>
                )}
              </div>
            </form>
          </div>
        )}

        {/* LIST */}
        <div className="mt-6">
          {loading ? (
            <p>Loading events...</p>
          ) : filteredEvents.length === 0 ? (
            <p>No events found.</p>
          ) : (
            <div className="grid md:grid-cols-2 gap-4">
              {filteredEvents.map((event) => (
                <div
                  key={event._id}
                  className="bg-gray-900 border border-gray-800 rounded-2xl p-4"
                >
                  <h3 className="text-xl font-semibold">{event.title}</h3>
                  <p className="text-gray-400 mt-1">{event.description}</p>

                  <p className="text-sm mt-2">
                    📍 {event.venue || "Venue not set"}
                  </p>
                  <p className="text-sm text-gray-500">
                    📅 {new Date(event.date).toDateString()}
                  </p>

                  {isEditor && (
                    <div className="flex gap-2 mt-4">
                      <button
                        onClick={() => handleEdit(event)}
                        className="flex-1 bg-yellow-600/20 rounded-xl p-2"
                      >
                        ✏️ Edit
                      </button>
                      <button
                        onClick={() => handleDelete(event._id)}
                        className="flex-1 bg-red-600/20 rounded-xl p-2"
                      >
                        🗑 Delete
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
