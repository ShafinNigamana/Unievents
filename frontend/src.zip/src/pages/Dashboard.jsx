import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";

export default function Dashboard() {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));

  if (!user) {
    navigate("/login");
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      <Navbar />

      <div className="max-w-6xl mx-auto p-6">
        <h1 className="text-3xl font-bold">Welcome, {user.name} 👋</h1>
        <p className="text-gray-400 mt-1">
          Manage university events and archives from one platform.
        </p>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-3 gap-4 mt-6">
          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
            <p className="text-gray-400 text-sm">Role</p>
            <h2 className="text-2xl font-semibold mt-1">{user.role}</h2>
          </div>

          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
            <p className="text-gray-400 text-sm">Enrollment</p>
            <h2 className="text-2xl font-semibold mt-1">
              {user.enrollmentNumber}
            </h2>
          </div>

          <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
            <p className="text-gray-400 text-sm">Department</p>
            <h2 className="text-2xl font-semibold mt-1">
              {user.department || "Not set"}
            </h2>
          </div>
        </div>

        {/* Profile Card */}
        <div className="mt-6 bg-gray-900 border border-gray-800 rounded-2xl p-6">
          <h2 className="text-xl font-semibold">Your Profile</h2>

          <div className="grid md:grid-cols-2 gap-4 mt-4 text-gray-200">
            <div className="bg-gray-950 border border-gray-800 rounded-xl p-4">
              <p className="text-gray-400 text-sm">Email</p>
              <p className="mt-1 font-semibold">{user.email}</p>
            </div>

            <div className="bg-gray-950 border border-gray-800 rounded-xl p-4">
              <p className="text-gray-400 text-sm">Semester</p>
              <p className="mt-1 font-semibold">{user.semester || "Not set"}</p>
            </div>

            <div className="bg-gray-950 border border-gray-800 rounded-xl p-4">
              <p className="text-gray-400 text-sm">Phone</p>
              <p className="mt-1 font-semibold">{user.phone || "Not set"}</p>
            </div>

            <div className="bg-gray-950 border border-gray-800 rounded-xl p-4">
              <p className="text-gray-400 text-sm">Status</p>
              <p className="mt-1 font-semibold text-green-400">
                Logged In ✅
              </p>
            </div>
          </div>

          <button
            onClick={() => navigate("/events")}
            className="mt-6 w-full bg-blue-600 hover:bg-blue-500 transition rounded-xl p-3 font-semibold"
          >
            Go to Events →
          </button>
        </div>
      </div>
    </div>
  );
}
