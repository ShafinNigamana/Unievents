import { Link, useNavigate } from "react-router-dom";

export default function Navbar() {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));

  const logout = () => {
    localStorage.removeItem("user");
    navigate("/login");
  };

  return (
    <div className="w-full bg-gray-900 border-b border-gray-800">
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <Link to="/dashboard" className="text-xl font-bold text-white">
          Unievents 🎓
        </Link>

        <div className="flex items-center gap-3">
          <Link
            to="/dashboard"
            className="px-3 py-2 rounded-xl hover:bg-gray-800 text-gray-200"
          >
            Dashboard
          </Link>

          <Link
            to="/events"
            className="px-3 py-2 rounded-xl hover:bg-gray-800 text-gray-200"
          >
            Events
          </Link>

          {user && (
            <span className="hidden md:block text-gray-400 text-sm">
              {user.name} ({user.role})
            </span>
          )}

          <button
            onClick={logout}
            className="bg-red-600 hover:bg-red-500 transition px-4 py-2 rounded-xl font-semibold"
          >
            Logout
          </button>
        </div>
      </div>
    </div>
  );
}
